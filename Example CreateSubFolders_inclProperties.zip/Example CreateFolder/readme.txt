creates subfolder .\CAD with filled properties Titel, Beschreibung

note - you need to have the VDSUtils.dll (part of Quickstart 2015R1 / R2 environments)